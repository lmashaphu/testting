package tests;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

public class BaseTestChrome {
    public WebDriver driver;

    @BeforeTest
    public void setBaseURL1() {
        ChromeOptions capabilities = new ChromeOptions();
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver(capabilities);
        driver.manage().window().maximize();// maximizing the window
        driver.get("http://demoblaze.com/");
    }

    @AfterTest
    public void endSession() {
        driver.quit();
    }


}


