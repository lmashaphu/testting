package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import org.openqa.selenium.Alert;


import static java.lang.Thread.*;


public class SampleTestFireFox extends BaseTestFireFox {

    @Test
    public void goToWomensPage() throws InterruptedException {
        driver.findElement(By.xpath("//a[normalize-space()='Sign up']")).click(); // Clicking sign up link
        //sleep(10000);
        driver.findElement(By.xpath("//input[@id='sign-username']")).sendKeys("dineo222"); // entering username
        sleep(10000);
        driver.findElement(By.xpath("//input[@id='sign-password']")).sendKeys("dineo1988"); // entering password
        sleep(10000);
        driver.findElement(By.xpath("//button[normalize-space()='Sign up']")).click(); // clicking sign up button
        sleep(10000);

        // Switching to Alert
        Alert alert = driver.switchTo().alert();
        // Capturing alert message.
        String alertMessage = driver.switchTo().alert().getText();
        // Displaying alert message
        System.out.println(alertMessage);
        // Accepting alert
        alert.accept();
        driver.findElement(By.xpath("//a[normalize-space()='Log in']")).click();
        driver.findElement(By.xpath("//input[@id='loginusername']")).click(); // clicking username textbox
        sleep(10000);

        driver.findElement(By.xpath("//input[@id='loginusername']")).sendKeys("dineo222");// entering username
        driver.findElement(By.xpath("//input[@id='loginpassword']")).click();
        driver.findElement(By.xpath("//input[@id='loginpassword']")).sendKeys("dineo1988"); // entering password
        sleep(10000);
        driver.findElement(By.xpath("//button[normalize-space()='Log in']")).click(); // clicking log in
        sleep(10000);
        driver.findElement(By.xpath("//a[normalize-space()='Phones']")).click(); // clicking phones link
        sleep(10000);
        driver.findElement(By.xpath("//a[normalize-space()='Samsung galaxy s6']")).click();// selecting Samsung galaxy s6
        sleep(10000);

        WebDriverWait wait = new WebDriverWait(driver, 15);
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Add to cart']"))); // wait for Clicking Add cart button to be clickable
        driver.findElement(By.xpath("//a[normalize-space()='Add to cart']")).click(); // clicking Add cart button
        // Switching to Alert
        Alert alert2 = driver.switchTo().alert();
        // Capturing alert message.
        String alertMessage2 = driver.switchTo().alert().getText();
        // Displaying alert message
        System.out.println(alertMessage);
        // Accepting alert
        alert.accept();

        driver.findElement(By.xpath("//li[@class='nav-item active']//a[@class='nav-link']")).click(); // clicking home link
        driver.findElement(By.xpath("//a[normalize-space()='Laptops']")).click(); // clicking Laptops option
        driver.findElement(By.xpath("//a[normalize-space()='MacBook air']")).click();// clicking MacBook air link
        driver.findElement(By.xpath("//a[normalize-space()='Add to cart']")).click(); // clicking Add to cart

        // Switching to Alert
        Alert alert1 = driver.switchTo().alert();
        // Capturing alert message.
        String alertMessage1= driver.switchTo().alert().getText();
        // Displaying alert message
        System.out.println(alertMessage);
        alert.accept();

        driver.findElement(By.xpath("//li[@class='nav-item active']//a[@class='nav-link']")).click(); // clicking home link
        driver.findElement(By.xpath("//a[normalize-space()='Monitors']")).click(); // clicking Monitors option
        driver.findElement(By.xpath("//a[normalize-space()='Apple monitor 24']")).click(); // clicking Apple monitor item
        driver.findElement(By.xpath("//a[normalize-space()='Add to cart']")).click(); // clicking Add cart button

        // Switching to Alert
        Alert alert3 = driver.switchTo().alert();
        // Capturing alert message.
        String alertMessage3= driver.switchTo().alert().getText();
        // Displaying alert message
        System.out.println(alertMessage);
        alert.accept();

        driver.findElement(By.xpath("//a[normalize-space()='Cart']")).click();// clicking cart button
        driver.findElement(By.xpath("//button[normalize-space()='Place Order']")).click(); // clicking place order button
        driver.findElement(By.xpath("//input[@id='name']")).click(); // clicking name text box
        driver.findElement(By.xpath("//input[@id='name']")).sendKeys("Sharps");// entering name

        driver.findElement(By.xpath("//input[@id='country']")).click();// clicking country text box
        driver.findElement(By.xpath("//input[@id='country']")).sendKeys("South Africa");// entering country
        driver.findElement(By.xpath("//input[@id='city']")).click(); // clicking city textbx
        driver.findElement(By.xpath("//input[@id='city']")).sendKeys("CAPETOWN");// entering city
        driver.findElement(By.xpath("//input[@id='card']")).click(); // clicking card text box
        driver.findElement(By.xpath("//input[@id='card']")).sendKeys("Makro"); // entering credit details
        driver.findElement(By.xpath("//input[@id='month']")).click();// clicking month text box
        driver.findElement(By.xpath("//input[@id='month']")).sendKeys("August"); // Entering Month
        driver.findElement(By.xpath("//input[@id='year']")).click(); // clicking year text box
        driver.findElement(By.xpath("//input[@id='year']")).sendKeys("2021"); // entering year
        driver.findElement(By.xpath("//button[normalize-space()='Purchase']")).click();// clicking purchaser button
        driver.findElement(By.xpath("//h2[normalize-space()='Thank you for your purchase!']")); // verifying Thank you for your purchase
        driver.findElement(By.xpath("//p[contains(@class,'lead text-muted')]")); // verifying details of the purchaser
        driver.findElement(By.xpath("//button[normalize-space()='OK']")).click(); // Clicking Ok button

    }
}





